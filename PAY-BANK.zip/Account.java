import java.util.*;

public class Account {
  private String name;
  private double balance;
  private String uuid;
  private User holder;
  private ArrayList<Transaction> transactions;

  public Account(String name, User holder, Bank theBank) {
    this.name = name;
    this.holder = holder;
    this.uuid = theBank.getNewUserAccountUUID();
    this.transactions = new ArrayList<Transaction>();
  }

  public String getUUID() {
    return this.uuid;
  }

  public String getsummaryline() {
    double balance = this.getBalance();
    if (balance >= 0) {
      return String.format("%s : ₹%.02f : %s ", this.uuid, balance, this.name);
    } else {
      return String.format("%s : ₹(%.02f) : %s ", this.uuid, balance, this.name);
    }
  }

  public double getBalance() {
    double balance = 0;
    for (Transaction t : this.transactions) {
      balance += t.getAmount();
    }
    return balance;
  }

  public void printHistory() {
    System.out.printf("\n\nTransaction history for account %s\n", this.uuid);
    for (int i = this.transactions.size() - 1; i >= 0; i--) {
      System.out.println(this.transactions.get(i).getsummaryline());
    }
    System.out.println();
  }

  public void addTransaction(double amount, String memo) {
    Transaction trans = new Transaction(amount, memo, this);
    this.transactions.add(trans);
  }
}