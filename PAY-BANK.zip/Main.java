import java.util.*;
import java.io.*;
public class Main{
  public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    Bank theBank= new Bank("PAY-BANK");
    System.out.print("Kindly Enter your name : ");
    String name = sc.nextLine();
    System.out.println();
    System.out.print("Enter your Password : ");
    String password = sc.nextLine();
    System.out.println();
    User newUser=theBank.add_user(name," ",password);
    Account newAccount= new Account("Checking" , newUser,theBank );
    newUser.addAccount(newAccount);
    theBank.addAccount(newAccount);
    User curr_User;
    while(true){
      curr_User=Main.mainMenuPrompt(theBank,sc);
      Main.printUserMenu(curr_User,sc);
    }
  }
  public static User mainMenuPrompt(Bank theBank ,Scanner sc){
    String userID;
    String pin;
    User authUser;
    do{
      System.out.printf("\n\nWelcome to %s \n\n",theBank.getName());
      System.out.printf("Enter User ID: ");
      userID=sc.nextLine();
      System.out.printf("Enter Pin: ");
      pin=sc.nextLine();
      authUser = theBank.userlogin(userID, pin);
      if(authUser==null){
        System.out.println("Invalid User ID/Pin, Kindly try again");
      }
    }
    while(authUser==null);
    return authUser;
  } 
  public static void printUserMenu(User theUser,Scanner sc){
    theUser.printAccountSummary();
    int choice ;
    do{
      System.out.printf("Welcome %s ,What will you like to do?\n",theUser.getfirstname());
       System.out.println("1) Show Account History ");
       System.out.println("2) Withdrawl ");
       System.out.println("3) Deposit");
       System.out.println("4) Transfer ");
       System.out.println("5) Quit ");
       System.out.println(" ");
       System.out.println(" Enter your Choice: ");
       choice =sc.nextInt();
       if(choice<1 || choice>5){
         System.out.println(" Invalid Choice ,Kindly enter valid Choice");
       }
    }
    while(choice<1 || choice>5);
    switch (choice){
      case 1:{
        printAccountHistory(theUser,sc);
        break;
      }
      case 2:{
        withdrawl(theUser,sc);
        break;
      }
      case 3:{
        deposit(theUser,sc);
        break;
      }
      case 4:{
        transfer(theUser,sc);
        break;
      }
      case 5:{
        sc.nextLine();
        break;
      }
      default :{
        System.out.println("Sorry we cannot process your request at this moment, kindly try again");
        
      }
    }
    if(choice !=5){
      printUserMenu(theUser, sc);
    }
  }
  public static void printAccountHistory(User theuser,Scanner sc){
    int theact;
    do{
      System.out.printf("Enter the number (1-%d) of the Account \nwhose transaction you want to see",theuser.numAccounts());
      theact =sc.nextInt() -1;
      if(theact<0 || theact>=theuser.numAccounts()){
        System.out.println("Invalid Account Number,Kindly try again");
      }
    }
    while(theact<0 || theact>=theuser.numAccounts());
    theuser.printTransHistory(theact);
  }
  public static void transfer(User theuser ,Scanner sc){
    int fromact;
    int toact;
    double amount;
    double acctBalanace;
    do{
      System.out.printf("Enter the number 1-%d of the account \n to trnasfer from: ",theuser.numAccounts());
      fromact=sc.nextInt()-1;
      if(fromact<0 || fromact>=theuser.numAccounts()){
        System.out.println("Invalid Account number ,kindly try Again");
      }
    }
    while(fromact<0 || fromact>=theuser.numAccounts());
    acctBalanace=theuser.getAccbalance(fromact);
    if(acctBalanace==0){
      System.out.println("Transaction cannot be performed with Zero Balance");
    }
    else{
      do{
        System.out.printf("Enter the number 1-%d of the account \n to trnasfer to: ",theuser.numAccounts());
        toact=sc.nextInt()-1;
        if(toact<0 || toact>=theuser.numAccounts()){
          System.out.println("Invalid Account number ,kindly try Again");
        }
      }
      while(toact<0 || toact>=theuser.numAccounts());
      if(toact==fromact){
        System.out.println("Transaction cannot be performed within the same Account");
      }
      else{
        boolean flag=false;
        do{
          System.out.printf("Enter the amount to transfer max ₹%.2f : ₹",acctBalanace);
          amount=sc.nextDouble();
          if(amount<= 0){
            System.out.println("Amount must be greater than Zero");
            flag=true;
          }
          else if(amount> acctBalanace){
            System.out.println("Amount must be not greater than Account Balance");
            flag=true;
          }
        }
        while(amount< 0 || amount>acctBalanace && !flag);
        if(flag){
          System.out.println("Transaction is Canceled");
        }
        else{
          System.out.println("Transaction is Successful");

          theuser.addAccTransaction(fromact,-1*amount,String.format("Transfer to account %s ",theuser.getaccuuid(toact)));
          theuser.addAccTransaction(toact,amount,String.format("Transfer to account %s ",theuser.getaccuuid(fromact)));
          
        }
      }
    }
  }
  public static void withdrawl(User theuser,Scanner sc){
    int fromact;
    double amount;
    double acctBalanace;
    String memo;
    do{
      System.out.printf("Enter the number 1-%d of the account \n to withdraw from: ",theuser.numAccounts());
      fromact=sc.nextInt()-1;
      if(fromact<0 || fromact>=theuser.numAccounts()){
        System.out.println("Invalid Account number ,kindly try Again");
      }
    }
    while(fromact<0 || fromact>=theuser.numAccounts());
    acctBalanace=theuser.getAccbalance(fromact);
    if(acctBalanace==0){
      System.out.println("Transaction cannot be performed within the Zero Balance");
    }
    else{
      boolean flag =false;
      do{
        System.out.printf("Enter the amount to withdraw max ₹%.2f : ₹",acctBalanace);
        amount=sc.nextDouble();
        if(amount <= 0){
          System.out.println("Amount must be greater than Zero");
          flag=true;
        }
        else if(amount > acctBalanace){
          System.out.println("Amount must be not greater than Account Balance");
          flag=true;
        }
      }
      while(amount < 0 || amount>acctBalanace && !flag) ;
      if(flag){
        System.out.println("Transaction is Canceled");
      }
      else{
        sc.nextLine();
        System.out.println("Enter the memo");
        memo=sc.nextLine();
        theuser.addAccTransaction(fromact, -1*amount, memo);
        System.out.println("Transaction is Successful");
      }
    }
  }
  public static void deposit(User theuser,Scanner sc){
    int toact;
    double amount;
    double acctBalanace;
    String memo;
    do{
      System.out.printf("Enter the number (1-%d) of the account \n to deposit in : ",theuser.numAccounts());
      toact=sc.nextInt()-1;
      if(toact<0 || toact>=theuser.numAccounts()){
        System.out.println("Invalid Account number ,kindly try Again");
      }
    }
    while(toact<0 || toact>=theuser.numAccounts());
    acctBalanace=theuser.getAccbalance(toact);
    boolean flag = false;
    do{
      System.out.printf("Enter the amount to Deposit ");
      amount=sc.nextDouble();
      if(amount<= 0){
        System.out.println("Amount must be greater than Zero");
        flag = true;
      }
    }
    while(amount< 0 && !flag);
    if(flag){
      System.out.println("Transaction is Canceled");
    }
    else{
      sc.nextLine();
      System.out.println("Enter the memo");
      memo=sc.nextLine();
      theuser.addAccTransaction(toact, amount, memo);
      System.out.println("Transaction is Successful");
    }
  } 
}