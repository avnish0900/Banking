import java.util.*;
public class Bank{
  private String name;
  private ArrayList<User> users;
  private ArrayList<Account> accounts;

  public Bank(String name){
    this.name=name;
    this.users=new ArrayList<User>();
    this.accounts=new ArrayList<Account>();
  }
  public String  getNewUserID(){
    String uuid;
    Random num=new Random();
    int length=6;
    boolean nonUnique;
    do{
      uuid="";
      for(int i=0;i<length;i++){
        uuid+=((Integer)num.nextInt(10)).toString();
      }
      nonUnique=false;
      for(User u: this.users){
        if(uuid.compareTo(u.getUUID())==0){
          nonUnique=true;
          break;
        }
      }
    }
    while(nonUnique);
    return uuid;
  }
  public String  getNewUserAccountUUID(){
    String uuid;
    Random num=new Random();
    int length=10;
    boolean nonUnique;
    do{
      uuid="";
      for(int i=0;i<length;i++){
        uuid+=((Integer)num.nextInt(10)).toString();
      }
      nonUnique=false;
      for(Account a: this.accounts){
        if(uuid.compareTo(a.getUUID())==0){
          nonUnique=true;
          break;
        }
      }
    }
    while(nonUnique);
    return uuid;
  }

  public void addAccount(Account curr_account){
    this.accounts.add(curr_account);
  }
  public User add_user(String firstname,String lastname,String pin){
    User newUser=new User(firstname, lastname,pin,this);
    this.users.add(newUser);
    Account newAccount = new Account("Savings", newUser,this );
    newUser.addAccount(newAccount);
    this.addAccount(newAccount);
    return newUser;
  }
  public User userlogin(String userID,String pin){
    for(User u:this.users){
      if(u.getUUID().compareTo(userID)==0 && u.validatepin(pin)){
        return u;
      }
    }
    return null;
  }
  public String getName(){
    return this.name;
  }
}