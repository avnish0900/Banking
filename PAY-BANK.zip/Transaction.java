import java.util.*;
public class Transaction{
  private double amount;
  private Date time;
  private String memo;
  private byte pin;
  private Account curr_Account;

  public Transaction(double amount,Account curr_account){
    this.amount=amount;
    this.curr_Account=curr_account;
    this.time=new Date();
    this.memo="";
  }
  public Transaction(double amount,String memo,Account curr_account){
    this(amount, curr_account);
    this.memo=memo;
  }
  public double getAmount(){
    return this.amount;
  }
  public String getsummaryline(){
    return String.format("%s : ₹%.02f : %s ", this.time.toString(),this.amount,this.memo);
  }
}