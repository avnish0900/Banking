import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class User{
  private String firstName;
  private String lastName;
  private String uuid;
  private byte pin[];
  private ArrayList<Account> accounts;

  public User(String first_name,String last_name,String pin, Bank theBank){
    this.firstName=first_name;
    this.lastName=last_name;
    try{
      MessageDigest md=MessageDigest.getInstance("MD5");
      this.pin=md.digest(pin.getBytes());
    }
    catch (NoSuchAlgorithmException e) {
      System.err.println("Server is down,Kindly try after some time");
      e.printStackTrace();
      System.exit(1);
    }
    this.uuid=theBank.getNewUserID();
    this.accounts =new ArrayList<Account>();
    System.out.printf("New User %s %s with ID %s is created",lastName,firstName,this.uuid);
  }
  public void addAccount(Account curr_account){
    this.accounts.add(curr_account);
  }
  public String getUUID(){
    return this.uuid;
  }
  public boolean validatepin(String pin){
    try{
      MessageDigest md=MessageDigest.getInstance("MD5");
      return MessageDigest.isEqual(md.digest(pin.getBytes()),this.pin);
    }
    catch(NoSuchAlgorithmException e){
      System.err.println("Server is down,Kindly try after some time");
      e.printStackTrace();
      System.exit(1);
    }
    return false;
  }
  public String getfirstname(){
    return this.firstName;
  }
  public void printAccountSummary(){
    System.out.printf("\n\n%s's accounts summary\n",this.firstName);
    for(int i=0;i<this.accounts.size();i++){
      System.out.printf("\t%d) %s \n",i+1,this.accounts.get(i).getsummaryline());
      this.accounts.get(i).getsummaryline();
    }
    System.out.println();
  }
  public int numAccounts(){
    return this.accounts.size();
  }
  public void printTransHistory(int acc_indx){
    this.accounts.get(acc_indx).printHistory();
  }
  public String getaccuuid(int acctIndex){
    return this.accounts.get(acctIndex).getUUID();
  }
  public void addAccTransaction(int acctIndex, double amount , String memo){
    this.accounts.get(acctIndex).addTransaction(amount,memo);
  }
  public double getAccbalance(int acctIndex){
    return this.accounts.get(acctIndex).getBalance();
  }
}